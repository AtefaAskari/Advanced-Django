from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.db.models import Sum
from sales.models import Sale
from trading.models import Trade

class AnalyticsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        total_sales = Sale.objects.aggregate(total_revenue=Sum('price_per_unit'))
        total_trades = Trade.objects.aggregate(total_traded=Sum('quantity'))
        
        data = {
            "total_sales_revenue": total_sales['total_revenue'] or 0,
            "total_traded_quantity": total_trades['total_traded'] or 0
        }
        return Response(data)
