import stripe # type: ignore
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
import requests

class MarketDataView(APIView):
    def get(self, request, symbol):
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey=your_api_key"
        response = requests.get(url)
        data = response.json()
        return Response(data)


stripe.api_key = settings.STRIPE_SECRET_KEY

class CreateCheckoutSession(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {'name': 'Trade Payment'},
                        'unit_amount': int(request.data['amount']) * 100,
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url='https://yourapp.com/success',
                cancel_url='https://yourapp.com/cancel',
            )
            return Response({"session_id": checkout_session.id})
        except Exception as e:
            return Response({"error": str(e)}, status=400)
